const mongoose =require('mongoose')

const userSchema = new mongoose.Schema({

    Firstname: {
        type: String,
        required: true
    },
    Lastname: {
        type: String,
        required: true
    },
    Username: {
        type: String,
        required: true
    },
    Password: {
        type: String,
        required:true
    },
    Email: {
        type: String,
        required: true
    },
    DOB: {
        type: String,
        required: true
    },
    Phonenumber: {
        type: String,
        required: true
    },

})

module.exports =mongoose.model('User',userSchema)
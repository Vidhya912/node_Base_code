const express = require('express')
const router = express.Router()
const bcrypt = require('bcrypt')
const User = require('../models/user')


router.get('/allusers', async(req,res) => {
    try{
        const users = await User.find()
        res.json( { statuscode :'200', message: 'User Retrieved successfully', user:users })
        //res.json(users)

    }catch(err){
        res.send('Error' + err)
    }
    
})


router.get('/:id', async(req,res) => {
    try{
        
        const user = await User.findById(req.params.id)
        res.json( { statuscode :'200', message: 'User Retrieved  successfully', user:user })
        //res.json(user)

    }catch(err){
        res.json( { statuscode :'500', message: 'please check the id' })
       // res.send('Error ' + err)
    }
    
})

router.post('/addUser' ,(req,res) => {
    User.find({Username:req.body.Username})
    .exec()
    .then(user =>{
        if(user.length >=1){
            return res.status(409).json({
                message:"User name already exists"
            })
        }else{
            bcrypt.hash(req.body.Password,10,(err,hash) =>{
                if(err){
                    return res.status(500).json({
                        error: err
                    })
                    } else{
                        const user =new User({
                            Firstname: req.body.Firstname,
                            Lastname: req.body.Lastname,
                            Username: req.body.Username,
                            Password: hash,
                            Email: req.body.Email,
                            DOB: req.body.DOB,
                            Phonenumber: req.body.Phonenumber
                        })
                        user.save()
                        .then(user => {
                            res.sendStatus(200).json({
                                message:'user Created'
        
                            })
                        })
                        .catch(err =>{
                            res.status(500).json({
                                error:err
                            })
                        })
                    }
            })

        }
    })
})


router.post('/signup',(req,res,next) =>{
    User.find({Username:req.body.Username})
    .exec()
    .then(user =>{
        if(user.length >=1){
            return res.status(409).json({
                message:"User name already exists"
            })
        }else{
            bcrypt.hash(req.body.Password,10,(err,hash) =>{
                if(err){
                    return res.status(500).json({
                        error: err
                    })
                    } else{
                        const user = new User({
                            
                            Firstname: req.body.Firstname,
                            Lastname: req.body.Lastname,
                            Username: req.body.Username,
                            Password: hash ,
                            Email: req.body.Email,
                            DOB: req.body.DOB,
                            Phonenumber: req.body.Phonenumber

                        })
                        user.save()
                        .then(user => {
                            res.sendStatus(200).json({
                                message:'user Created'
        
                            })
                        })
                        .catch(err =>{
                            res.status(500).json({
                                error:err
                            })
                        })
                    }
            })

        }
    })
   

})

router.post('/login',(req,res,next) =>{
    Username =req.body.Username
    Password = req.body.Password

    User.findOne({$or: [{Username:Username},{Password:Password}]})
    .then(user =>{
        if(user){
            bcrypt.compare(Password,user.Password,function(err,result){
                if(err){
                    res.json({
                        error:err
                    })
                }
                if(result){
                    //user.Password=null;
                    res.json({
                        message:'Login Sucessfull!!',
                        user
                    })
                }
                else{
                    res.json({
                        message:'Password does not match'
                    })
                }
            })

        }else{
            res.json({
                message:'No user Found'
            })
        }
    })
})

router.patch('/:id',async(req,res) => {
    try{
        const user = await User.findById(req.params.id)
        user.Username = req.body.Username,
        user.Firstname=req.body.Firstname,
        user.Lastname=req.body.Lastname,
       // user.Password=req.body.Password,
        user.Email=req.body.Email,
        user.DOB=req.body.DOB,
        user.Phonenumber=req.body.Phonenumber
        
        const a1 = await user.save()
        res.json( { statuscode :'200', message: 'User updated successfully', user:a1 })
        //res.json(a1)

    }catch(err){
        res.json( { statuscode :'500', message: ' Please check the id', user:user })
        //res.send('Error')
    }
})

router.delete('/:id', async(req,res) => {
    try{
        const user = await User.findById(req.params.id)
        
        const a1 = await user.remove()
        res.json( { statuscode :'200',message: 'User Deleted successfully' })

    }catch(err){
        res.json( { statuscode :'500', message: 'Please check the id', user:user })
        //res.send('Error' + err)
    }
    
})

module.exports = router